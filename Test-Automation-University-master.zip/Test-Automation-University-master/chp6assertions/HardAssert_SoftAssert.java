package com.testautomationu.chp5assertions;

import org.testng.annotations.Test;

public class HardAssert_SoftAssert
{
	@Test
	public void exampleAssertTest ()
	{
		System.out.println("1. Open Browser");
		
		System.out.println("2. Open Application");
		
		System.out.println("3. Sign Into The Application");
		
		System.out.println("4. Go To Home Page & Verify Home Page");
		
		System.out.println("5. Go To Search Page & Verify Search Page");
		
		System.out.println("6. Search For User");
		
		System.out.println("7. Sign Out Of The Application");		
	}
}