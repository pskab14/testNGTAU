package com.testautomationu.chp3annotations;

import org.testng.annotations.BeforeMethod;

public class DemoAnnotations 
{
	@BeforeMethod
	public void setUp ()
	{
		  
	}
}
